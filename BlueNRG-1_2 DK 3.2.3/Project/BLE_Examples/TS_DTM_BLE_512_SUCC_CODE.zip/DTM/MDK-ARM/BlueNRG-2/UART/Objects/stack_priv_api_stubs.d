.\uart\objects\stack_priv_api_stubs.o: ../../../../../Library/Bluetooth_LE/src/stack_priv_api_stubs.c
.\uart\objects\stack_priv_api_stubs.o: ..\..\..\..\..\Library\Bluetooth_LE\inc\stack_user_cfg.h
